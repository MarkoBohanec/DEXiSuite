DEXiEval Versions
=================

Version 1.2
-----------

Released: 2024-??-??

Added qualitative-quantitative (QQ) evaluation of alternatives.

Upgraded to using DEXiLibrary 1.2.

Version 1.1
-----------

Released: 2024-02-29

Upgraded to using DEXiLibrary 1.1.

Version 1.0
-----------

Released: 2023-10-03

Initial version, compatible with DEXiWin 1.0.
